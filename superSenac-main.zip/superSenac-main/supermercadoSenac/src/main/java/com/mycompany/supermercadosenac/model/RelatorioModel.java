
package com.mycompany.supermercadosenac.model;

public class RelatorioModel {
    
}
